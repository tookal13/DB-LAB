//2022664044	������
#include <stdio.h>

int main()
{
	printf("Hello, World!\n");
	printf("Kyungsung University\n");
	printf("Dept. of Computer Science\n");
} 
