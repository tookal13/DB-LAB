#include <stdio.h>
//2022664044  

int main(){
	printf("Hello, World.\nHello, World.\nHello, World. Kyungsung University.\nKyungsung University.\nKyungsung University. Dept. of Computer Science.\nHello, World. Kyungsung University. Dept. of Computer Science.");
	
	
}
