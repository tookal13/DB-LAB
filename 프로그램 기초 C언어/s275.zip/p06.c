//2022664044

#include <stdio.h>
int main(){
	int n;
	scanf("%d", &n);
	printf("The age of %d years is %d days.",n, n*365);
}
