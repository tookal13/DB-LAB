#include <stdio.h>
//2022664044  

int main(){
	long long a,b;
	
	scanf("%lld %lld",&a,&b);
	printf("%lld", a+b);
	 
	
}
